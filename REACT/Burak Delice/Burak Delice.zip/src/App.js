import "./App.scss";
import Character from "./pages/Character";

function App() {
  return (
    <div className="App">
      <Character />
    </div>
  );
}

export default App;
